package exception;

public class InvalidNumberEntered extends Exception {
}
