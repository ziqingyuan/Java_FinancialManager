package exception;

public class InvalidSpent extends Exception {
}
